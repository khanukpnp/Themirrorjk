# The Mirror Jammu Kashmir — Static Site

Modern, mobile-ready news/advocacy site with:
- Maroon theme, 3D title look, sticky nav with dropdowns
- Scrolling ticker, multilingual UI labels, client search
- Blog cards (JSON-driven) + sample posts
- YouTube vlog embed
- Digital clock (Europe/Zurich), Islamic & Hindi/Indian calendars via `Intl`
- Newsletter + Contact (Netlify Forms)
- Mobile sticky bottom bar
- Netlify CMS (admin) for content editing

## Local preview
Just open `index.html` in a browser.

## Deploy on GitHub Pages
1. Push this folder as your repo root (branch `main`).
2. GitHub Action in `.github/workflows/pages.yml` publishes to Pages automatically.
3. After Pages is live, open `/admin/` for Netlify CMS (GitHub backend).

