/* Clock in CEST and Calendars */
function updateClock(){
  const now = new Date();
  const fmt = new Intl.DateTimeFormat('en-CH',{weekday:'long', month:'long', day:'numeric', hour:'2-digit', minute:'2-digit', timeZone:'Europe/Zurich'});
  document.getElementById('clock').textContent = fmt.format(now) + ' — CEST';
  document.getElementById('year').textContent = now.getFullYear();
  try{
    document.getElementById('islamic-date').textContent =
      new Intl.DateTimeFormat('en-u-ca-islamic', {day:'numeric', month:'long', year:'numeric'}).format(now) + ' (Islamic)';
    document.getElementById('indian-date').textContent =
      new Intl.DateTimeFormat('en-u-ca-indian', {day:'numeric', month:'long', year:'numeric'}).format(now) + ' (Hindi/Indian)';
  }catch(e){
    document.getElementById('islamic-date').textContent = 'Islamic calendar not supported';
    document.getElementById('indian-date').textContent = 'Indian calendar not supported';
  }
}
setInterval(updateClock, 1000); updateClock();

/* Share */
function shareSite(){
  if (navigator.share){
    navigator.share({title:document.title, url:location.href}).catch(()=>{});
  } else {
    alert('Copy this link to share: ' + location.href);
  }
}

/* Contact modal */
function openContact(){ document.getElementById('contactModal').showModal(); }
function closeContact(){ document.getElementById('contactModal').close(); }

/* Layout ratio */
function updateLayoutRatio(val){
  document.querySelector('.main').style.gridTemplateColumns = val + '% ' + (100 - val) + '%';
  document.getElementById('ratioValue').textContent = val + '%';
}

/* Dark mode */
function toggleDarkMode(on){
  document.documentElement.classList.toggle('dark', on);
}

/* Simple i18n demo for some UI labels */
const i18n = {
  latestEditorial: {
    en:'Latest Editorial', de:'Aktuelles Editorial', fr:'Éditorial récent', ru:'Последняя редакционная статья',
    he:'מאמר המערכת האחרון', ur:'حالیہ اداریہ', hi:'नवीनतम संपादकीय', ar:'أحدث الافتتاحيات',
    es:'Último editorial', it:'Ultimo editoriale', nl:'Laatste hoofdartikel'
  },
  latestVlog: {
    en:'Latest Vlog', de:'Aktuelles Vlog', fr:'Vlog récent', ru:'Новый влог',
    he:'ולוג אחרון', ur:'تازہ ترین ولاگ', hi:'नवीनतम व्लॉग', ar:'أحدث مدونة فيديو',
    es:'Último vlog', it:'Ultimo vlog', nl:'Laatste vlog'
  }
};

function applyLanguage(lang){
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key = el.getAttribute('data-i18n');
    el.textContent = (i18n[key] && i18n[key][lang]) || i18n[key]['en'];
  });
}

/* Client-side search over loaded posts */
function searchSite(){
  const q = document.getElementById('searchInput').value.toLowerCase();
  const cards = document.querySelectorAll('#blogGrid .card');
  cards.forEach(c=>{
    const text = c.textContent.toLowerCase();
    c.style.display = text.includes(q) ? '' : 'none';
  });
}

/* Load posts generated as JSON (from /content/blog/index.json) */
async function loadPosts(){
  try{
    const res = await fetch('content/blog/index.json');
    const posts = await res.json();
    const grid = document.getElementById('blogGrid');
    grid.innerHTML='';
    posts.forEach(p=>{
      const c = document.createElement('article');
      c.className = 'card';
      c.innerHTML = `
        <img src="${p.cover || 'assets/placeholder.jpg'}" alt="" style="width:100%;border-radius:12px;aspect-ratio:16/9;object-fit:cover;margin-bottom:10px" />
        <h3>${p.title}</h3>
        <p><small>${new Date(p.date).toLocaleDateString()}</small></p>
        <p>${p.excerpt}</p>
        <a href="${p.url}">Read more →</a>`;
      grid.appendChild(c);
    });
  }catch(e){
    console.error('Failed to load posts', e);
  }
}
loadPosts();
