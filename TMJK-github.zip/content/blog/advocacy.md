---
title: "Human Rights & Global Advocacy — Starter"
date: 2025-11-02
cover: "/assets/sample2.jpg"
excerpt: "An example post showing how cards appear with images, dates, and excerpts."
---

Add your content here. Include YouTube links, images, and quotes.
