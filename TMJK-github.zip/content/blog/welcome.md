---
title: "Welcome to The Mirror JK"
date: 2025-11-03
cover: "/assets/sample1.jpg"
excerpt: "This is a sample editorial post to demonstrate the blog layout and Netlify CMS editing."
---

This is a placeholder article. Use **Netlify CMS** (admin panel) to edit or create new posts.
