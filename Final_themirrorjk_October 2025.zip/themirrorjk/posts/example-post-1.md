---
title: "Voices from the Valley: Testimony on arbitrary detentions and media blackout"
date: "2025-10-30"
tag: "Human Rights"
thumb: "/assets/sample-thumb2.jpg"
excerpt: "Families describe night raids, communication shutdowns, and fear. We document what officials deny."
---

We spoke with families whose loved ones were taken in night raids. Phones were confiscated, SIMs destroyed, and movement restricted.

This report is part of The Mirror JK's ongoing documentation project.
