# The Mirror Jammu Kashmir

Independent, rights-focused news and advocacy platform.

## What this repo contains
- Static responsive site (HTML/CSS/JS)
- 65% / 35% main layout:
  - Left: Latest Editorial & Opinion
  - Right: Latest Vlog / 现场报道
- Editable sections:
  - Blog / Opinion cards
  - Vlog block with placeholder video
  - Ticker text
  - Navigation dropdown links
  - Newsletter form (Netlify forms compatible)
  - Contact modal (Netlify forms ready)

## Local preview
1. Clone this repo.
2. Open `src/index.html` in your browser.

## Deploy to Netlify
You can:
- Drag & drop the `/src` folder into Netlify,
  OR
- Connect this GitHub repo in Netlify and set:
  - **Base directory:** `src`
  - **Build command:** (leave empty, this is static)
  - **Publish directory:** `src`

## Editing content
- Headlines / Articles:
  - In `index.html`, search for `<!-- ARTICLE CARD -->`
  - Duplicate `<article class="post-card">...</article>` and edit text.
- Vlog:
  - Replace `.video-placeholder` with an `<iframe>` from YouTube.
- Ticker:
  - Search for `id="ticker-marquee"` and edit its text.
- Contact:
  - Modal form at bottom of `index.html` is already set with `data-netlify="true"`.

## License
All content © The Mirror Jammu Kashmir. Code may be reused for non-commercial human rights / press freedom purposes with attribution.
