// CLOCK (CEST style text)
function updateClock() {
  const clockEl = document.getElementById("live-clock");
  if (!clockEl) return;
  const now = new Date();

  const weekday = now.toLocaleString("en-GB", { weekday: "long" });
  const day = now.getDate();
  const monthShort = now.toLocaleString("en-GB", { month: "short" });
  const year = now.getFullYear();
  clockEl.textContent = `${weekday}, ${day} ${monthShort} ${year} — CEST`;
}
setInterval(updateClock, 1000);
updateClock();

// Simple modal logic for Contact Form
const modalOverlay = document.querySelector("[data-modal]");
const modalCard = document.querySelector("[data-modal-card]");
const openModalBtn = document.querySelector("[data-open-modal]");
const closeModalBtns = document.querySelectorAll("[data-close-modal]");

if (openModalBtn && modalOverlay) {
  openModalBtn.addEventListener("click", () => {
    modalOverlay.style.display = "flex";
  });
}

if (closeModalBtns && modalOverlay) {
  closeModalBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      modalOverlay.style.display = "none";
    });
  });
}

// close when clicking outside card
if (modalOverlay && modalCard) {
  modalOverlay.addEventListener("click", (e) => {
    if (!modalCard.contains(e.target)) {
      modalOverlay.style.display = "none";
    }
  });
}

// (Optional) you can later hook real YouTube iframe here.
