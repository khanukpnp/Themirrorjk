# THE MIRROR JAMMU KASHMIR

Static responsive news / advocacy site with:
- Maroon editorial theme
- Live digital clock + Islamic/Hindi date line
- Scrolling BREAKING ticker
- Multilingual dropdown + search bar
- Full nav with dropdowns
- Blog (editorial/opinion) + Vlog (YouTube embed)
- Newsletter signup form (Netlify Forms ready)
- Contact modal form (Netlify Forms ready)
- Mobile sticky bottom bar
- Admin panel (`admin.html`) to update homepage text using localStorage

## How to edit homepage content
1. Open `admin.html` locally in your browser.
2. Update ticker, blog posts, vlog video URL, footer contact.
3. Click "Save".
4. Reload `index.html` — the changes appear.

No backend required. Everything is static.

## Deploy on Netlify
Drag-and-drop the folder.

## Customization
Replace `assets/logo.png` with your own logo (already included here).
Update colors in `styles.css` under `:root` if desired.
