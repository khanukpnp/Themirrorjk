// === LIVE CLOCK + DATES ===
// We assume user timezone Europe/Zurich (CET/CEST)
function updateClockAndDates() {
  const clockEl = document.getElementById("liveClock");
  const islamicEl = document.getElementById("islamicDate");
  const hindiEl = document.getElementById("hindiDate");
  const yearNowEl = document.getElementById("yearNow");

  const now = new Date();
  // digital clock HH:MM:SS
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const ss = String(now.getSeconds()).padStart(2, "0");
  if (clockEl) {
    clockEl.textContent = `${hh}:${mm}:${ss} CEST`;
  }

  // basic fallback dates (client-side approximation)
  const gregorianStr = now.toLocaleDateString("en-GB", {
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric"
  });

  if (islamicEl) {
    islamicEl.textContent = `Islamic: ${gregorianStr}`;
  }
  if (hindiEl) {
    hindiEl.textContent = `Hindi: ${gregorianStr}`;
  }

  if (yearNowEl) {
    yearNowEl.textContent = now.getFullYear();
  }
}
setInterval(updateClockAndDates, 1000);
updateClockAndDates();


// === CONTACT MODAL OPEN/CLOSE ===
const modal = document.getElementById("contactModal");
const openButtons = document.querySelectorAll(".open-contact-modal");
const closeButtons = document.querySelectorAll(".modal-close, .modal-exit");

openButtons.forEach(btn => {
  btn.addEventListener("click", (e) => {
    e.preventDefault();
    if (modal) {
      modal.style.display = "flex";
      modal.setAttribute("aria-hidden", "false");
    }
  });
});

closeButtons.forEach(btn => {
  btn.addEventListener("click", () => {
    if (modal) {
      modal.style.display = "none";
      modal.setAttribute("aria-hidden", "true");
    }
  });
});


// === LOCALSTORAGE-CONTROLLED CONTENT ===
// This lets admin.html update homepage text without editing code.

function applyDynamicContent() {
  // Ticker
  const tickerTextEl = document.getElementById("tickerText");
  const tickerSaved = localStorage.getItem("tickerText");
  if (tickerTextEl && tickerSaved) {
    tickerTextEl.textContent = tickerSaved;
  }

  // Blog post 1
  const blog1TitleEl = document.getElementById("blogPost1Title");
  const blog1BodyEl = document.getElementById("blogPost1Body");
  const blog1TitleSaved = localStorage.getItem("blogPost1Title");
  const blog1BodySaved = localStorage.getItem("blogPost1Body");
  if (blog1TitleEl && blog1TitleSaved) blog1TitleEl.textContent = blog1TitleSaved;
  if (blog1BodyEl && blog1BodySaved) blog1BodyEl.textContent = blog1BodySaved;

  // Blog post 2
  const blog2TitleEl = document.getElementById("blogPost2Title");
  const blog2BodyEl = document.getElementById("blogPost2Body");
  const blog2TitleSaved = localStorage.getItem("blogPost2Title");
  const blog2BodySaved = localStorage.getItem("blogPost2Body");
  if (blog2TitleEl && blog2TitleSaved) blog2TitleEl.textContent = blog2TitleSaved;
  if (blog2BodyEl && blog2BodySaved) blog2BodyEl.textContent = blog2BodySaved;

  // Vlog
  const vlogEmbedEl = document.getElementById("vlogEmbed");
  const vlogDescEl = document.getElementById("vlogDesc");
  const vlogEmbedSrcSaved = localStorage.getItem("vlogEmbedSrc");
  const vlogDescSaved = localStorage.getItem("vlogDesc");
  if (vlogEmbedEl && vlogEmbedSrcSaved) vlogEmbedEl.src = vlogEmbedSrcSaved;
  if (vlogDescEl && vlogDescSaved) vlogDescEl.textContent = vlogDescSaved;

  // Footer contact
  const footerEmailEl = document.getElementById("footerEmail");
  const footerPhoneEl = document.getElementById("footerPhone");
  const footerEmailSaved = localStorage.getItem("footerEmail");
  const footerPhoneSaved = localStorage.getItem("footerPhone");
  if (footerEmailEl && footerEmailSaved) footerEmailEl.textContent = footerEmailSaved;
  if (footerPhoneEl && footerPhoneSaved) footerPhoneEl.textContent = footerPhoneSaved;
}

applyDynamicContent();
