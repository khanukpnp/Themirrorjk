// helper to show success text for 2 seconds
function flashMessage(el) {
  if (!el) return;
  el.textContent = "Saved ✔";
  setTimeout(() => {
    el.textContent = "";
  }, 2000);
}

// load existing values from localStorage when admin opens
function loadAdminValues() {
  const fields = [
    { key:"tickerText",        elId:"admTicker" },
    { key:"blogPost1Title",    elId:"admBlog1Title" },
    { key:"blogPost1Body",     elId:"admBlog1Body" },
    { key:"blogPost2Title",    elId:"admBlog2Title" },
    { key:"blogPost2Body",     elId:"admBlog2Body" },
    { key:"vlogEmbedSrc",      elId:"admVlogSrc" },
    { key:"vlogDesc",          elId:"admVlogDesc" },
    { key:"footerEmail",       elId:"admFooterEmail" },
    { key:"footerPhone",       elId:"admFooterPhone" }
  ];

  fields.forEach(f => {
    const saved = localStorage.getItem(f.key);
    if (saved && document.getElementById(f.elId)) {
      document.getElementById(f.elId).value = saved;
    }
  });
}

// SAVE handlers
function saveTicker() {
  const val = document.getElementById("admTicker").value.trim();
  localStorage.setItem("tickerText", val);
  flashMessage(document.getElementById("msgTicker"));
}

function saveBlog1() {
  const t = document.getElementById("admBlog1Title").value.trim();
  const b = document.getElementById("admBlog1Body").value.trim();
  localStorage.setItem("blogPost1Title", t);
  localStorage.setItem("blogPost1Body", b);
  flashMessage(document.getElementById("msgBlog1"));
}

function saveBlog2() {
  const t = document.getElementById("admBlog2Title").value.trim();
  const b = document.getElementById("admBlog2Body").value.trim();
  localStorage.setItem("blogPost2Title", t);
  localStorage.setItem("blogPost2Body", b);
  flashMessage(document.getElementById("msgBlog2"));
}

function saveVlog() {
  const src = document.getElementById("admVlogSrc").value.trim();
  const desc = document.getElementById("admVlogDesc").value.trim();
  localStorage.setItem("vlogEmbedSrc", src);
  localStorage.setItem("vlogDesc", desc);
  flashMessage(document.getElementById("msgVlog"));
}

function saveFooter() {
  const email = document.getElementById("admFooterEmail").value.trim();
  const phone = document.getElementById("admFooterPhone").value.trim();
  localStorage.setItem("footerEmail", email);
  localStorage.setItem("footerPhone", phone);
  flashMessage(document.getElementById("msgFooter"));
}

// attach listeners
document.addEventListener("click", (e) => {
  const action = e.target.getAttribute("data-action");
  if (!action) return;

  if (action === "saveTicker") saveTicker();
  if (action === "saveBlog1") saveBlog1();
  if (action === "saveBlog2") saveBlog2();
  if (action === "saveVlog") saveVlog();
  if (action === "saveFooter") saveFooter();
});

loadAdminValues();
